INSERT INTO [EDDB].[dbo].[Users]
         (UserName, Name, Surname, Password, Mail, Role)  
VALUES   ('admin', 'admin', 'admin', 'admin', 'admin@admin.com', '0')